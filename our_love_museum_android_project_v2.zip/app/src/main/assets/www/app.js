/* Our Little Museum — front-end prototype.
   Add Supabase URL + anon key in config.js to enable shared realtime rooms.
   Do not put a service-role key in a browser project. */
const CONFIG = window.MUSEUM_CONFIG || { supabaseUrl: "", supabaseAnonKey: "" };
const $ = (id) => document.getElementById(id);
const screens = ["welcome","setup","museum"];
let memories = [];
let selectedFile = null, rotation = 0, zoom = 1, activeRoom = "Our Beginning";
let roomId = "", playerId = Math.random().toString(36).slice(2,10), playerName = "Player One";
let playMode = "single";
const LOCAL_KEY = "ourLittleMuseum.memories.v1";
try { const saved = localStorage.getItem(LOCAL_KEY); if (saved) memories = JSON.parse(saved) || []; } catch(e) { memories = []; }
function saveLocalMemories(){ try { localStorage.setItem(LOCAL_KEY, JSON.stringify(memories)); } catch(e) { toast("Storage is full. Try fewer or smaller photos."); } }

let sb = null, channel = null, scene = null, renderer = null, camera = null, world = null, player = null, otherPlayer = null, frames = [], keys = {}, moveInterval = null;
const roomNames = ["Our Beginning","Little Adventures","Favorite Moments","Letters to Forever"];
function showScreen(id){screens.forEach(s=>$(s).classList.toggle("hidden",s!==id));window.scrollTo({top:0,behavior:"smooth"});if(id==="museum"){setTimeout(init3D,80);}}
function toast(msg){const t=$("toast");t.textContent=msg;t.classList.remove("hidden");clearTimeout(toast.timer);toast.timer=setTimeout(()=>t.classList.add("hidden"),2600);}
function escapeHTML(s){return String(s||"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function roomFromURL(){const u=new URL(location.href);return u.searchParams.get("room")||"";}
function createRoomId(){return Math.random().toString(36).slice(2,6).toUpperCase()+"-"+Math.random().toString(36).slice(2,6).toUpperCase();}
function openRoom(id){roomId=id||createRoomId();const url=new URL(location.href);if(playMode==="multi")url.searchParams.set("room",roomId);else url.searchParams.delete("room");history.replaceState({}, "",url);$("museumTitle").innerHTML='Welcome to <em>our story.</em>'; $("playerLabel").textContent=playerName+" · exploring";$("connection").textContent=playMode==="single"?"Solo exploration · saved on this device":(CONFIG.supabaseUrl?"Connecting to our world…":"Multiplayer needs online setup");$("shareCode").value=roomId;$("shareLink").value=url.href;showScreen("museum");if(playMode==="multi")connectRealtime();else{$("onlineLabel").textContent="Solo mode · your memories stay on this device";if(otherPlayer)otherPlayer.visible=false;}}
async function connectRealtime(){
 if(!CONFIG.supabaseUrl||!CONFIG.supabaseAnonKey||!window.supabase){$("connection").textContent="Multiplayer not connected";$("onlineLabel").textContent="Online play needs a Supabase project and setup";toast("Solo mode works now. Multiplayer needs online setup.");return;}
 if(otherPlayer)otherPlayer.visible=true;
 try{sb=window.supabase.createClient(CONFIG.supabaseUrl,CONFIG.supabaseAnonKey);channel=sb.channel("museum-"+roomId,{config:{presence:{key:playerId},broadcast:{self:false}}});
 channel.on("presence",{event:"sync"},()=>{const states=channel.presenceState();const count=Object.keys(states).length;$("onlineLabel").textContent=count>1?"Your person is here ♥":"Waiting for your person…";});
 channel.on("broadcast",{event:"move"},({payload})=>{if(payload.id===playerId)return;if(otherPlayer){otherPlayer.position.set(payload.x,0.8,payload.z);otherPlayer.rotation.y=payload.rot||0;}});
 channel.on("broadcast",{event:"memories"},({payload})=>{if(payload.id!==playerId&&Array.isArray(payload.memories)){memories=payload.memories;renderMemories();refreshFrames();toast("Your shared memories were updated ♥");}});
 channel.subscribe(async status=>{if(status==="SUBSCRIBED"){await channel.track({name:playerName,joined_at:new Date().toISOString()});$("connection").textContent="Live private room · "+roomId;}});
 }catch(e){$("connection").textContent="Realtime connection unavailable";console.error(e);}
}
function broadcastMove(){if(channel)channel.send({type:"broadcast",event:"move",payload:{id:playerId,x:player.position.x,z:player.position.z,rot:player.rotation.y}});}
function broadcastMemories(){if(channel)channel.send({type:"broadcast",event:"memories",payload:{id:playerId,memories}});}
function renderMemories(){
 const list=$("memoryList");$("memoryCount").textContent=memories.length;
 if(!memories.length){list.innerHTML='<div class="empty-list">No memories added yet. Start with a favorite photo.</div>';return;}
 list.innerHTML=memories.map((m,i)=>`<div class="memory-item"><img src="${m.image}" alt=""><div class="memory-meta"><strong>${escapeHTML(m.title||"A favorite moment")}</strong><small>${escapeHTML(m.room)}${m.date?" · "+escapeHTML(m.date):""}</small></div><button data-delete="${i}">Remove memory ×</button></div>`).join("");
 list.querySelectorAll("[data-delete]").forEach(b=>b.onclick=()=>{memories.splice(+b.dataset.delete,1);saveLocalMemories();renderMemories();broadcastMemories();refreshFrames();});
}
$("photoFile").addEventListener("change",e=>{const f=e.target.files&&e.target.files[0];if(!f)return;if(!f.type.startsWith("image/"))return toast("Please choose an image.");if(f.size>12*1024*1024)return toast("Choose a photo under 12 MB for this demo.");selectedFile=f;const r=new FileReader();r.onload=()=>{$("photoPreview").src=r.result;$("photoPreview").classList.remove("hidden");$("emptyPreview").classList.add("hidden");$("addMemory").disabled=false;rotation=0;zoom=1;$("zoom").value=1;updateTransform();};r.readAsDataURL(f);});
function updateTransform(){$("photoPreview").style.transform=`rotate(${rotation}deg) scale(${zoom})`;}
$("zoom").addEventListener("input",e=>{zoom=+e.target.value;updateTransform();});
$("rotate").onclick=()=>{rotation=(rotation+90)%360;updateTransform();};
function processedImage(src,rot,scale){return new Promise(resolve=>{const img=new Image();img.onload=()=>{const max=1400;let w=img.naturalWidth,h=img.naturalHeight;const ratio=Math.min(1,max/Math.max(w,h));w=Math.round(w*ratio);h=Math.round(h*ratio);const swap=rot%180!==0;const c=document.createElement("canvas");c.width=swap?h:w;c.height=swap?w:h;const ctx=c.getContext("2d");ctx.translate(c.width/2,c.height/2);ctx.rotate(rot*Math.PI/180);ctx.scale(scale,scale);ctx.drawImage(img,-w/2,-h/2,w,h);resolve(c.toDataURL("image/jpeg",.84));};img.src=src;});}
$("addMemory").onclick=async()=>{if(!selectedFile)return;const src=$("photoPreview").src;const image=await processedImage(src,rotation,zoom);memories.push({id:Math.random().toString(36).slice(2),image,title:$("caption").value.trim()||"A favorite moment",date:$("memoryDate").value,story:$("story").value.trim(),room:$("room").value});saveLocalMemories();selectedFile=null;$("photoFile").value="";$("photoPreview").src="";$("photoPreview").classList.add("hidden");$("emptyPreview").classList.remove("hidden");$("caption").value="";$("memoryDate").value="";$("story").value="";$("addMemory").disabled=true;rotation=0;zoom=1;$("zoom").value=1;updateTransform();renderMemories();broadcastMemories();refreshFrames();toast("A new memory is saved ♥");};
$("clearMemories").onclick=()=>{if(confirm("Clear all memories from this browser session?")){memories=[];saveLocalMemories();renderMemories();refreshFrames();broadcastMemories();}};
$("setupOpen").onclick=()=>showScreen("setup");$("backWelcome").onclick=()=>showScreen("welcome");$("editBtn").onclick=()=>showScreen("setup");
$("createRoom").onclick=()=>{playerName=$("playerName").value.trim()||"Player One";playMode=$("playMode").value||"single";openRoom(createRoomId());};
$("joinRoom").onclick=()=>{$("joinBox").classList.toggle("hidden");};
$("joinGo").onclick=()=>{const val=$("roomCode").value.trim();if(!val)return toast("Paste a museum link or room code first.");let id=val;try{const u=new URL(val);id=u.searchParams.get("room")||val;}catch{}playerName=$("playerName").value.trim()||"Player Two";playMode="multi";$("playMode").value="multi";openRoom(id.toUpperCase());};
$("enterFromSetup").onclick=()=>{playerName=$("playerName").value.trim()||"Player One";playMode=$("playMode").value||"single";openRoom(playMode==="multi"?(roomFromURL()||createRoomId()):"");};
$("shareBtn").onclick=()=>{$("shareModal").classList.remove("hidden");const url=new URL(location.href);url.searchParams.set("room",roomId);$("shareLink").value=url.href;$("shareCode").value=roomId;$("shareStatus").textContent=CONFIG.supabaseUrl?"Live connection configured. Anyone with the room link can try to join; add authentication for strict privacy.":"This preview link does not transfer photos to another device. Configure Supabase using README.md to share the actual museum.";};
$("copyLink").onclick=()=>copyText($("shareLink").value);$("copyCode").onclick=()=>copyText(roomId);
function copyText(s){if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(s).then(()=>toast("Copied ♥")).catch(()=>fallbackCopy(s));else fallbackCopy(s);}
function fallbackCopy(s){const el=document.createElement("textarea");el.value=s;document.body.appendChild(el);el.select();document.execCommand("copy");el.remove();toast("Copied ♥");}
document.querySelectorAll("[data-close]").forEach(b=>b.onclick=()=>{if(b.dataset.close==="modal")$("memoryModal").classList.add("hidden");if(b.dataset.close==="share")$("shareModal").classList.add("hidden");});
$("leaveMuseum").onclick=()=>{if(renderer){renderer.dispose();renderer=null;scene=null;}showScreen("welcome");};
document.querySelectorAll(".room-tab").forEach(b=>b.onclick=()=>{activeRoom=b.dataset.room;document.querySelectorAll(".room-tab").forEach(x=>x.classList.toggle("active",x===b));$("roomLabel").textContent="Gallery · "+activeRoom;if(scene){player.position.set(0,.8,3.5);camera.position.set(0,4.8,8);camera.lookAt(0,1,0);refreshFrames();}});
function showMemory(m){$("modalTitle").textContent=m.title||"A favorite moment";$("modalDate").textContent=[m.room,m.date].filter(Boolean).join(" · ");$("modalStory").textContent=m.story||"A little moment, kept here forever.";const wrap=$("modalImageWrap");wrap.innerHTML="";const img=document.createElement("img");img.src=m.image;img.alt=m.title||"Memory";wrap.appendChild(img);$("memoryModal").classList.remove("hidden");}
function refreshFrames(){if(!scene)return;frames.forEach(f=>scene.remove(f.group));frames=[];const items=memories.filter(m=>m.room===activeRoom);items.forEach((m,i)=>{const g=new THREE.Group();const x=(i-(items.length-1)/2)*2.25;g.position.set(x,2.35,-5.7);const frame=new THREE.Mesh(new THREE.BoxGeometry(1.62,1.55,.16),new THREE.MeshStandardMaterial({color:0xb78a51,metalness:.55,roughness:.35}));g.add(frame);const mat=new THREE.MeshBasicMaterial({map:new THREE.CanvasTexture(makePhotoTexture(m)),side:THREE.DoubleSide});const pic=new THREE.Mesh(new THREE.PlaneGeometry(1.38,1.25),mat);pic.position.z=.095;g.add(pic);const plaque=new THREE.Mesh(new THREE.BoxGeometry(1.5,.24,.09),new THREE.MeshStandardMaterial({color:0x261c2c}));plaque.position.y=-.91;plaque.position.z=.07;g.add(plaque);const label=makeText(m.title||"A favorite moment");label.position.set(0,-.91,.13);g.add(label);g.userData.memory=m;scene.add(g);frames.push({group:g,memory:m});});}
function makePhotoTexture(m){const c=document.createElement("canvas");c.width=256;c.height=230;const x=c.getContext("2d");x.fillStyle="#33253a";x.fillRect(0,0,256,230);const img=new Image();img.onload=()=>{const r=Math.max(256/img.width,230/img.height),w=img.width*r,h=img.height*r;x.drawImage(img,(256-w)/2,(230-h)/2,w,h);};img.src=m.image;return c;}
function makeText(text){const c=document.createElement("canvas");c.width=512;c.height=64;const ctx=c.getContext("2d");ctx.fillStyle="#f2d8a9";ctx.font="bold 23px Georgia";ctx.textAlign="center";ctx.fillText(text.slice(0,32),256,40);const tex=new THREE.CanvasTexture(c);const mesh=new THREE.Mesh(new THREE.PlaneGeometry(1.42,.18),new THREE.MeshBasicMaterial({map:tex,transparent:true}));return mesh;}
function init3D(){
 const host=$("gameCanvas");if(!window.THREE){host.querySelector(".loading-scene").textContent="3D library unavailable — check your internet connection.";return;}if(renderer){renderer.dispose();renderer=null;}host.querySelector(".loading-scene")?.remove();
 const w=host.clientWidth,h=host.clientHeight;scene=new THREE.Scene();scene.background=new THREE.Color(0x171321);scene.fog=new THREE.Fog(0x171321,12,28);
 camera=new THREE.PerspectiveCamera(58,w/h,.1,100);camera.position.set(0,4.8,8);
 renderer=new THREE.WebGLRenderer({antialias:true,alpha:false});renderer.setPixelRatio(Math.min(devicePixelRatio,1.8));renderer.setSize(w,h);renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.outputColorSpace=THREE.SRGBColorSpace;host.prepend(renderer.domElement);
 scene.add(new THREE.HemisphereLight(0xffd9e9,0x242035,2.1));const light=new THREE.PointLight(0xffd49c,90,20);light.position.set(0,5,-3);scene.add(light);const pink=new THREE.PointLight(0xc785d9,45,14);pink.position.set(-5,3,0);scene.add(pink);
 const floor=new THREE.Mesh(new THREE.PlaneGeometry(28,28),new THREE.MeshStandardMaterial({color:0x302538,roughness:.7,metalness:.12}));floor.rotation.x=-Math.PI/2;floor.position.y=-.03;floor.receiveShadow=true;scene.add(floor);
 const wallMat=new THREE.MeshStandardMaterial({color:0x3b2c43,roughness:.9});const goldMat=new THREE.MeshStandardMaterial({color:0xc59b5d,metalness:.5,roughness:.35});
 const back=new THREE.Mesh(new THREE.BoxGeometry(15,6,.35),wallMat);back.position.set(0,3,-6.2);scene.add(back);
 [-7.4,7.4].forEach(x=>{const wall=new THREE.Mesh(new THREE.BoxGeometry(.35,6,15),wallMat);wall.position.set(x,3,1);scene.add(wall);});
 for(let i=-6;i<=6;i+=2){const col=new THREE.Mesh(new THREE.BoxGeometry(.08,5.6,.1),goldMat);col.position.set(i,3,-5.95);scene.add(col);}
 const ceiling=new THREE.Mesh(new THREE.PlaneGeometry(15,15),new THREE.MeshStandardMaterial({color:0x201a2b,side:THREE.DoubleSide}));ceiling.rotation.x=Math.PI/2;ceiling.position.y=6;scene.add(ceiling);
 // Ceiling lamps
 for(let x=-5;x<=5;x+=2.5){const bulb=new THREE.Mesh(new THREE.SphereGeometry(.12,12,8),new THREE.MeshBasicMaterial({color:0xffe5b3}));bulb.position.set(x,5.65,-1);scene.add(bulb);const p=new THREE.PointLight(0xffd9a4,15,7);p.position.set(x,5.2,-1);scene.add(p);}
 // Central pedestal and flowers
 const ped=new THREE.Mesh(new THREE.CylinderGeometry(.6,.75,.55,32),goldMat);ped.position.set(0,.27,-1);scene.add(ped);const orb=new THREE.Mesh(new THREE.SphereGeometry(.27,24,16),new THREE.MeshStandardMaterial({color:0xd79ab0,emissive:0x55203b,emissiveIntensity:.7,metalness:.3}));orb.position.set(0,.9,-1);scene.add(orb);
 // Player capsule and partner
 function makeAvatar(color,accent){const g=new THREE.Group();const body=new THREE.Mesh(new THREE.CapsuleGeometry(.32,.65,5,12),new THREE.MeshStandardMaterial({color,roughness:.65}));body.position.y=.75;body.castShadow=true;g.add(body);const head=new THREE.Mesh(new THREE.SphereGeometry(.24,16,12),new THREE.MeshStandardMaterial({color:0xf0c8ad,roughness:.8}));head.position.y=1.38;g.add(head);const hair=new THREE.Mesh(new THREE.SphereGeometry(.245,16,8,0,Math.PI*2,0,Math.PI*.55),new THREE.MeshStandardMaterial({color:accent}));hair.position.y=1.43;g.add(hair);const heart=new THREE.Mesh(new THREE.SphereGeometry(.09,12,8),new THREE.MeshBasicMaterial({color:0xffc4d7}));heart.position.set(0,1.08,.28);g.add(heart);return g;}
 player=makeAvatar(0x8f6db1,0x352239);player.position.set(-1,.0,3.3);scene.add(player);otherPlayer=makeAvatar(0xd58f9f,0x593343);otherPlayer.position.set(1,.0,3.3);otherPlayer.visible=(playMode==="multi" && !!CONFIG.supabaseUrl);scene.add(otherPlayer);
 // Stanchions + velvet ropes
 for(let z=-3;z<=2;z+=2){[-5.7,5.7].forEach(x=>{const post=new THREE.Mesh(new THREE.CylinderGeometry(.055,.09,.85,12),goldMat);post.position.set(x,.42,z);scene.add(post);const cap=new THREE.Mesh(new THREE.SphereGeometry(.12,12,8),goldMat);cap.position.set(x,.88,z);scene.add(cap);});}
 refreshFrames();camera.lookAt(0,1.1,0);
 const ray=new THREE.Raycaster(),pointer=new THREE.Vector2();
 renderer.domElement.addEventListener("pointerdown",e=>{const rect=renderer.domElement.getBoundingClientRect();pointer.x=((e.clientX-rect.left)/rect.width)*2-1;pointer.y=-((e.clientY-rect.top)/rect.height)*2+1;ray.setFromCamera(pointer,camera);const hits=ray.intersectObjects(frames.flatMap(f=>f.group.children),true);if(hits.length){let o=hits[0].object;while(o&&!o.userData.memory&&o.parent)o=o.parent;const f=frames.find(f=>f.group===o);if(f)showMemory(f.memory);else{const nearest=frames.sort((a,b)=>a.group.position.distanceTo(player.position)-b.group.position.distanceTo(player.position))[0];if(nearest&&nearest.group.position.distanceTo(player.position)<8)showMemory(nearest.memory);}}else{const floorHits=ray.intersectObject(floor);if(floorHits.length){const p=floorHits[0].point;player.position.x=Math.max(-5.5,Math.min(5.5,p.x));player.position.z=Math.max(-1,Math.min(4.5,p.z));broadcastMove();}}});
 const onKey=e=>{const k=e.key.toLowerCase();if(["arrowup","arrowdown","arrowleft","arrowright","w","a","s","d"].includes(k)){keys[k]=true;if(e.target.tagName!=="INPUT")e.preventDefault();}};const offKey=e=>keys[e.key.toLowerCase()]=false;window.addEventListener("keydown",onKey);window.addEventListener("keyup",offKey);
 document.querySelectorAll("[data-move]").forEach(b=>{const start=e=>{e.preventDefault();keys[b.dataset.move]=true;};const stop=e=>{e.preventDefault();keys[b.dataset.move]=false;};b.addEventListener("pointerdown",start);b.addEventListener("pointerup",stop);b.addEventListener("pointerleave",stop);b.addEventListener("pointercancel",stop);});
 const clock=new THREE.Clock();let lastSend=0;function animate(){if(!renderer||!scene)return;requestAnimationFrame(animate);const dt=Math.min(clock.getDelta(),.05),speed=3.2*dt;let dx=0,dz=0;if(keys.w||keys.arrowup||keys.forward)dz-=1;if(keys.s||keys.arrowdown||keys.back)dz+=1;if(keys.a||keys.arrowleft||keys.left)dx-=1;if(keys.d||keys.arrowright||keys.right)dx+=1;if(dx||dz){const len=Math.hypot(dx,dz);dx/=len;dz/=len;player.position.x=Math.max(-5.8,Math.min(5.8,player.position.x+dx*speed));player.position.z=Math.max(-1,Math.min(4.8,player.position.z+dz*speed));player.rotation.y=Math.atan2(dx,dz);lastSend+=dt;if(lastSend>.12){broadcastMove();lastSend=0;}}
 camera.position.lerp(new THREE.Vector3(player.position.x,player.position.y+4.1,player.position.z+6.6),.07);camera.lookAt(player.position.x,1.05,player.position.z-1.5);renderer.render(scene,camera);}
 animate();window.addEventListener("resize",resize3D,{passive:true});
}
function resize3D(){if(!renderer||!camera)return;const host=$("gameCanvas");camera.aspect=host.clientWidth/host.clientHeight;camera.updateProjectionMatrix();renderer.setSize(host.clientWidth,host.clientHeight);}
const existing=roomFromURL();if(existing){$("roomCode").value=existing;}
renderMemories();