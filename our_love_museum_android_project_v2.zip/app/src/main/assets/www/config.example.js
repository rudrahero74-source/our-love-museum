// Copy this file to config.js and fill in your Supabase project values.
// Never use a service_role key in a browser app.
window.MUSEUM_CONFIG = {
  supabaseUrl: "https://YOUR-PROJECT.supabase.co",
  supabaseAnonKey: "YOUR_SUPABASE_ANON_KEY"
};