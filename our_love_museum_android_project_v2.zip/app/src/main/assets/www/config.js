// Optional multiplayer settings. Fill these only after setting up Supabase.
window.MUSEUM_CONFIG = { supabaseUrl: "", supabaseAnonKey: "" };
