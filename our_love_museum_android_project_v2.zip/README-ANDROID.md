# Our Little Museum Android project

This is an Android Studio/Gradle project that wraps the website in a WebView and supports the Android photo picker. It includes the website in `app/src/main/assets/www`, so the core app opens without needing to host the frontend.

## What works in this starter
- Solo museum mode
- Local photo memories saved in the app's WebView storage
- Photo upload, rotation, zoom, captions, dates, stories and memory rooms
- 3D gallery and movement controls
- A multiplayer mode selector and a Supabase Realtime connection hook

## What still needs setup
- The multiplayer feature is not ready for real couple use until a Supabase project is configured; shared photo persistence and secure invite-only access must also be implemented/configured. In this build, solo mode is the reliable mode.
- The project is source code, not a signed release APK. The GitHub Actions workflow builds a debug APK in the cloud.

## Get an APK without installing Android Studio locally
1. Create/sign in to a GitHub account.
2. Create a new repository (private recommended).
3. Upload the contents of this folder to the repository root. On GitHub's website, use **Add file → Upload files**; upload all files/folders from this ZIP after extracting it.
4. Open the repository's **Actions** tab and run **Build Android APK** (or push to `main`).
5. Open the completed workflow run, scroll to **Artifacts**, and download `our-little-museum-debug-apk`.
6. Extract the downloaded artifact ZIP. It contains `app-debug.apk`. Open it on your Android phone and allow installation from that source if Android asks.

The debug APK is for personal testing. Publishing on Google Play requires a signed release build and store setup.

## Important privacy note
Solo memories are stored locally on that device. They are not automatically uploaded or backed up. Don't treat room links as private authentication. For actual shared photo libraries and invite-only multiplayer, add Supabase Auth, Storage, database tables and Row Level Security before sharing personal photos.
